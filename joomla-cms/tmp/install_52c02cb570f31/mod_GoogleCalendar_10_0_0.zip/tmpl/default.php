<?php
/**
* @copyright	Copyright (C) 2012 Jan Maayt All rights reserved.
* @license		GNU/GPL, see http://www.gnu.org/copyleft/gpl.html
*/
defined('_JEXEC') or die('Restricted access'); ?>

<?php echo $code;?>
